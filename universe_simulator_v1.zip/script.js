const canvas = document.getElementById("space");
const ctx = canvas.getContext("2d");

const slider = document.getElementById("timeSlider");
const yearLabel = document.getElementById("yearLabel");
const eraName = document.getElementById("eraName");
const stateTitle = document.getElementById("stateTitle");
const description = document.getElementById("description");
const objects = document.getElementById("objects");
const temperature = document.getElementById("temperature");
const stars = document.getElementById("stars");
const expansion = document.getElementById("expansion");
const objectCount = document.getElementById("objectCount");
const timePill = document.getElementById("timePill");
const quickButtons = document.getElementById("quickButtons");

const states = [
  {
    year: "Present day",
    era: "Stelliferous Era",
    title: "A universe filled with galaxies",
    desc: "Stars, galaxies, planets and large-scale cosmic structures dominate the observable universe. Dark energy is already driving accelerated expansion.",
    objects: "Stars + galaxies",
    temp: "~2.7 K cosmic microwave background",
    stars: "Active",
    expansion: "Accelerating",
    density: 1.0
  },
  {
    year: "~1 million years",
    era: "Stelliferous Era",
    title: "The cosmic neighborhood changes",
    desc: "On this timescale the universe is still broadly recognizable. Individual stellar and galactic evolution matters more than the overall cosmological change.",
    objects: "Stars + galaxies",
    temp: "Slightly colder",
    stars: "Active",
    expansion: "Accelerating",
    density: .9
  },
  {
    year: "~1 billion years",
    era: "Stelliferous Era",
    title: "A much older universe",
    desc: "Many stars have evolved or disappeared, while new stars can still form in suitable gas-rich environments. Cosmic expansion continues.",
    objects: "Galaxies + remnants",
    temp: "Colder",
    stars: "Declining",
    expansion: "Accelerating",
    density: .78
  },
  {
    year: "~1 trillion years",
    era: "Late Stelliferous Era",
    title: "Star formation becomes rare",
    desc: "Gas available for making new stars is increasingly depleted or locked away. Long-lived low-mass stars become especially important.",
    objects: "Long-lived stars",
    temp: "Very cold",
    stars: "Much lower",
    expansion: "Accelerating",
    density: .55
  },
  {
    year: "~100 trillion years",
    era: "Degenerate Era",
    title: "Starlight fades",
    desc: "Conventional star formation is expected to have largely ended in many future scenarios. White dwarfs, neutron stars and black holes become important.",
    objects: "Stellar remnants",
    temp: "Extremely cold",
    stars: "Nearly ended",
    expansion: "Accelerating",
    density: .32
  },
  {
    year: "~10⁴⁰ years",
    era: "Degenerate Era",
    title: "A darkening cosmic landscape",
    desc: "Under some particle-physics assumptions, matter itself may eventually undergo additional changes. The exact future depends on physics not yet settled.",
    objects: "Remnants + black holes",
    temp: "Near absolute zero",
    stars: "Ended",
    expansion: "Dominant",
    density: .16
  },
  {
    year: "~10¹⁰⁰ years",
    era: "Black Hole Era",
    title: "Black holes dominate the story",
    desc: "If black holes eventually evaporate through Hawking radiation, the universe becomes progressively more dilute and dark over enormous timescales.",
    objects: "Black holes + radiation",
    temp: "Extremely close to 0 K",
    stars: "None",
    expansion: "Dominant",
    density: .07
  },
  {
    year: "Far future",
    era: "Dark Era",
    title: "An extremely dilute universe",
    desc: "In the simplest long-term picture, very little organized structure remains. The universe approaches a cold, dark state, although unknown physics could alter this picture.",
    objects: "Sparse particles + radiation",
    temp: "Approaches 0 K",
    stars: "None",
    expansion: "Continues",
    density: .025
  }
];

function resize() {
  canvas.width = innerWidth * devicePixelRatio;
  canvas.height = innerHeight * devicePixelRatio;
  canvas.style.width = innerWidth + "px";
  canvas.style.height = innerHeight + "px";
  ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);
}
addEventListener("resize", resize);
resize();

let particles = [];
function makeParticles() {
  particles = [];
  for (let i = 0; i < 220; i++) {
    particles.push({
      x: Math.random(),
      y: Math.random(),
      r: Math.random() * 1.7 + .2,
      a: Math.random() * .8 + .1,
      tw: Math.random() * 6.28
    });
  }
}
makeParticles();

let currentDensity = 1;
function draw(t) {
  const w = innerWidth, h = innerHeight;
  ctx.clearRect(0,0,w,h);

  const centerX = w/2, centerY = h/2;
  const spread = 1.1 + currentDensity * .7;

  particles.forEach((p, i) => {
    const angle = p.tw + t * 0.00003 * (i % 2 ? 1 : -1);
    const radiusX = (p.x - .5) * w * spread;
    const radiusY = (p.y - .5) * h * spread;
    const x = centerX + radiusX + Math.sin(angle) * 4;
    const y = centerY + radiusY + Math.cos(angle) * 4;

    let alpha = p.a * Math.max(.18, currentDensity);
    ctx.beginPath();
    ctx.arc(x,y,p.r,0,Math.PI*2);
    ctx.fillStyle = `rgba(210,220,255,${alpha})`;
    ctx.fill();
  });

  // A subtle central cosmic glow for visual orientation.
  const glow = ctx.createRadialGradient(centerX,centerY,0,centerX,centerY,Math.min(w,h)*.35);
  glow.addColorStop(0, `rgba(120,100,255,${.045*currentDensity})`);
  glow.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = glow;
  ctx.fillRect(0,0,w,h);

  requestAnimationFrame(draw);
}
requestAnimationFrame(draw);

function render(index) {
  const s = states[index];
  yearLabel.textContent = s.year;
  eraName.textContent = s.era;
  stateTitle.textContent = s.title;
  description.textContent = s.desc;
  objects.textContent = s.objects;
  temperature.textContent = s.temp;
  stars.textContent = s.stars;
  expansion.textContent = s.expansion;
  objectCount.textContent = s.objects + " dominate this model state";
  timePill.textContent = s.year.toUpperCase();
  currentDensity = s.density;

  document.querySelectorAll(".timeline-dot").forEach((dot, i) => {
    dot.classList.toggle("active", i === index);
  });
}

states.forEach((s, i) => {
  const b = document.createElement("button");
  b.textContent = s.year;
  b.onclick = () => {
    slider.value = i;
    render(i);
  };
  quickButtons.appendChild(b);
});

slider.addEventListener("input", e => render(Number(e.target.value)));
render(0);
